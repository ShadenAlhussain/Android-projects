package com.example.android.bookstoreapp;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.bookstoreapp.data.BookContract;


public class BookCursorAdapter extends CursorAdapter {
    public BookCursorAdapter(Context context, Cursor c, int flags) {
        super(context, c, 0);
    }

    /**
     * Makes a new blank list item view. No data is set (or bound) to the views yet.
     *
     * @param context app context
     * @param cursor  The cursor from which to get the data.
     * @param parent  The parent to which the new view is attached to
     * @return the newly created list item view.
     */
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.book_list, parent, false);
    }

    @Override
    public void bindView(View view, final Context context, final Cursor cursor) {
        TextView bookNameTextView = view.findViewById(R.id.book_name);
        TextView bookPriceTextView = view.findViewById(R.id.book_price);
        final TextView bookQuantityTextView = view.findViewById(R.id.book_quantity);
        ImageView sell_img = view.findViewById(R.id.buy_book_img);


        // Find the columns of book attributes that we're interested in
        int bookNameIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_PRODUCT_NAME);
        int bookPriceIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_PRICE);
        final int bookQuantityIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_QUANTITY);
        int idIndex = cursor.getColumnIndex(BookContract.BookEntry._ID);

        // Read the book attributes from the Cursor for the current book
        final int id = cursor.getInt(idIndex);
        String bookName = cursor.getString(bookNameIndex);
        String bookPrice = cursor.getString(bookPriceIndex);
        String bookQuantity = cursor.getString(bookQuantityIndex);

        if (TextUtils.isEmpty(bookQuantity)) {
            bookQuantity = context.getString(R.string.unknown_num);
        }
        if (TextUtils.isEmpty(bookName)) {
            bookName = context.getString(R.string.unknown);
        }
        if (TextUtils.isEmpty(bookPrice)) {
            bookPrice = context.getString(R.string.unknown_num);
        }
        // Update the TextViews with the attributes for the current book
        bookNameTextView.setText(bookName);
        bookPriceTextView.setText(bookPrice);
        bookQuantityTextView.setText(bookQuantity);

        sell_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int quantity = 0;
                String quantityString = bookQuantityTextView.getText().toString();
                quantity = Integer.parseInt(quantityString);
                if (quantity <= 0) {
                    Toast.makeText(context, "cannot sell more", Toast.LENGTH_SHORT).show();

                } else {
                    quantity--;
                    bookQuantityTextView.setText("" + quantity);
                    ContentValues values = new ContentValues();
                    values.put(BookContract.BookEntry.COLUMN_BOOK_QUANTITY, quantity);
                    // update quantity
                    context.getContentResolver().update(ContentUris.withAppendedId(
                            BookContract.BookEntry.CONTENT_URI, id), values, null, null);
                    Log.e("uridP", ContentUris.withAppendedId(
                            BookContract.BookEntry.CONTENT_URI, id).toString());
                }
            }
        });
    }
}
