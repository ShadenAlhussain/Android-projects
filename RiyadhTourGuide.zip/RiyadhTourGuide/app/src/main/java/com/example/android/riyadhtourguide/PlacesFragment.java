package com.example.android.riyadhtourguide;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class PlacesFragment extends Fragment {


    public PlacesFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.list_view, container, false);
        // create Array list
        final ArrayList<Place> places = new ArrayList<>();
        places.add(new Place(getString(R.string.kingdom_centre), getString(R.string.kingdome_info), R.drawable.kingdom_center));
        places.add(new Place(getString(R.string.alfaisaliah), getString(R.string.alfaisaliah_info), R.drawable.alfaisaliah_mall));
        places.add(new Place(getString(R.string.king_abdullah_park), getString(R.string.king_park_info), R.drawable.king_abdullah_park));
        places.add(new Place(getString(R.string.princes_park), getString(R.string.prin_park_info), R.drawable.princess_abdulaziz_park));
        places.add(new Place(getString(R.string.bowling), getString(R.string.bowling_info), R.drawable.bowling_center));
        places.add(new Place(getString(R.string.alaghar_club), getString(R.string.club_info), R.drawable.hores_club));
        places.add(new Place(getString(R.string.nakheel_mall), getString(R.string.nakheel_mall), R.drawable.nakheel_mall));
        places.add(new Place(getString(R.string.salam_park), getString(R.string.salam_info), R.drawable.salam_park));

        // Create an {@link PlaceAdapter}, whose data source is a list of {@link Place}s. The
        // adapter knows how to create list items for each item in the list.
        PlaceAdapter adapter = new PlaceAdapter(getActivity(), places, R.color.place_cate);
        ListView listView = (ListView) rootView.findViewById(R.id.list_view);
        listView.setAdapter(adapter);
        return rootView;
    }

}
