package com.example.android.riyadhtourguide;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class HospitalFragment extends Fragment {


    public HospitalFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.list_view, container, false);
        // create Array list
        final ArrayList<Place> places = new ArrayList<>();
        places.add(new Place(getString(R.string.alhabib_hospital), getString(R.string.alhabib_hos_info), R.drawable.habib_hospital));
        places.add(new Place(getString(R.string.alhammadi_hospital), getString(R.string.alhammadi_hospital_info), R.drawable.alhammadi_nuzha));
        places.add(new Place(getString(R.string.dallah_hospital), getString(R.string.dallah_hos_info), R.drawable.dallah_hospital));

        // Create an {@link PlaceAdapter}, whose data source is a list of {@link Place}s. The
        // adapter knows how to create list items for each item in the list.
        PlaceAdapter adapter = new PlaceAdapter(getActivity(), places, R.color.place_cate);
        ListView listView = (ListView) rootView.findViewById(R.id.list_view);
        // Make the {@link ListView} use the {@link PlaceAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Place} in the list.
        listView.setAdapter(adapter);
        return rootView;
    }
}
