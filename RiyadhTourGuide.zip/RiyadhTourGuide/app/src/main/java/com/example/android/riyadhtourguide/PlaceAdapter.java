package com.example.android.riyadhtourguide;


import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class PlaceAdapter extends ArrayAdapter<Place> {
    private int mColorResourceId;

    public PlaceAdapter(Context context, ArrayList<Place> places, int mColorResourceId) {
        super(context, 0, places);
        this.mColorResourceId = mColorResourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listView = convertView;
        if (listView == null) {
            listView = LayoutInflater.from(getContext()).inflate(R.layout.list_detail, parent, false);
        }
        Place currentPlace = getItem(position);
        TextView listText = (TextView) listView.findViewById(R.id.text_word);
        listText.setText(currentPlace.getTitle());

        TextView detailText = (TextView) listView.findViewById(R.id.detail_word);
        detailText.setText(currentPlace.getDetail());

        ImageView imgList = (ImageView) listView.findViewById(R.id.image_list);
        imgList.setImageResource(currentPlace.getImgResource());

        // Set the theme color for the list view
        View textContainer = listView.findViewById(R.id.text_container);
        // Find the color that the resource ID maps to
        int color = ContextCompat.getColor(getContext(), mColorResourceId);
        // Set the background color of the text container View
        textContainer.setBackgroundColor(color);
        return listView;
    }
}
