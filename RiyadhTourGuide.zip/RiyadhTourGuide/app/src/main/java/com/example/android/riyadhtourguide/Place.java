package com.example.android.riyadhtourguide;

public class Place {
    private String title;
    private String detail;
    private int imgResource;

    public Place(String title, String detail, int imgResourse) {
        this.title = title;
        this.detail = detail;
        this.imgResource = imgResourse;
    }

    public String getTitle() {
        return title;
    }

    public String getDetail() {
        return detail;
    }

    public int getImgResource() {
        return imgResource;
    }
}
