package com.example.android.riyadhtourguide;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class ResturantsFragment extends Fragment {


    public ResturantsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.list_view, container, false);
        // create Array list
        final ArrayList<Place> places = new ArrayList<>();
        places.add(new Place(getString(R.string.fairuz_rest), getString(R.string.fairuz_rest_info), R.drawable.fairuz_garden_rest));
        places.add(new Place(getString(R.string.lusin_rest), getString(R.string.lusin_rest_info), R.drawable.lusin_rest));

        PlaceAdapter adapter = new PlaceAdapter(getActivity(), places, R.color.place_cate);
        ListView listView = (ListView) rootView.findViewById(R.id.list_view);
        listView.setAdapter(adapter);
        return rootView;
    }
}
