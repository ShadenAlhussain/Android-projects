package com.example.android.newsapp2;



public class News {
    /**
     * section name of the news
     */
    private String sectionName;
    /**
     * The title of the news
     */
    private String webTitle;
    /**
     * The type of the news
     */
    private String newsType;
    /**
     * date of the news
     */
    private String date;
    /**
     * Website URL of the news
     */
    private String url;
    /**
     * the author of the stories
     */
    private String author;

    /**
     * Constructs a new {@link News} object.
     *
     * @param sectionName is the section name of the news
     * @param webTitle    The title of the news
     * @param date        when the news happened
     * @param url         is website URL of the news
     */
    public News(String sectionName, String webTitle, String newsType, String date, String url) {
        this.sectionName = sectionName;
        this.webTitle = webTitle;
        this.newsType = newsType;
        this.date = date;
        this.url = url;
    }

    /**
     * Constructs a new {@link News} object.
     *
     * @param sectionName is the section name of the news
     * @param webTitle    The title of the news
     * @param date        when the news happened
     * @param url         is website URL of the news
     * @param author      is the author of the stories
     */
    public News(String sectionName, String webTitle, String newsType, String date, String url, String author) {
        this.sectionName = sectionName;
        this.webTitle = webTitle;
        this.newsType = newsType;
        this.date = date;
        this.url = url;
        this.author = author;
    }

    public String getSectionName() {
        return sectionName;
    }

    public String getWebTitle() {
        return webTitle;
    }

    public String getNewsType() {
        return newsType;
    }

    public String getDate() {
        return date;
    }

    public String getUrl() {
        return url;
    }

    public String getAuthor() {
        return author;
    }

}