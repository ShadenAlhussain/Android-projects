package com.example.android.newsapp2;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class NewsAdapter extends ArrayAdapter<News> {

    public NewsAdapter(Context context, List<News> news) {
        super(context, 0, news);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Check if there is an existing list item view (called convertView) that we can reuse,
        // otherwise, if convertView is null, then inflate a new list item layout.
        View listItem = convertView;
        if (listItem == null) {
            listItem = LayoutInflater.from(getContext()).inflate(
                    R.layout.news_list, parent, false);
        }
        // Find the news at the given position in the list of news
        News currentNews = getItem(position);
        //Find the TextView with view ID section name
        TextView section = listItem.findViewById(R.id.section_text);
        // Display the section name of the current news in that TextView
        section.setText(currentNews.getSectionName());
        String sectionNameText = currentNews.getSectionName();
        // Get the appropriate background color based on the current section name
        section.setBackgroundColor(getSectionNameColor(sectionNameText));
        //Find the TextView with view ID type
        TextView newsType = listItem.findViewById(R.id.type_news);
        // Display the type of news of the current news in that TextView
        newsType.setText(currentNews.getNewsType());
        //Find the TextView with view ID title
        TextView title = listItem.findViewById(R.id.cate_title);
        // Display the title of news of the current news in that TextView
        title.setText(currentNews.getWebTitle());

        //Find the TextView with view ID author
        TextView author = listItem.findViewById(R.id.author);
        // Display the author of news of the current news in that TextView
        author.setText(currentNews.getAuthor());
        String authorCheck = (currentNews.getAuthor());
        author.setText(getAuthorName(authorCheck));

        // Find the TextView with view ID date
        TextView dateN = listItem.findViewById(R.id.date);
        // Display the date of news of the current news in that TextView
        dateN.setText(currentNews.getDate());
        return listItem;
    }

    private int getSectionNameColor(String sectionName) {
        int sectionColorResourceId;
        switch (sectionName) {
            case "Science":
                sectionColorResourceId = R.color.science;
                break;
            case "Society":
                sectionColorResourceId = R.color.society;
                break;
            case "Business":
                sectionColorResourceId = R.color.business;
                break;
            case "Politics":
                sectionColorResourceId = R.color.politics;
                break;
            case "Opinion":
                sectionColorResourceId = R.color.opinion;
                break;
            case "Teacher Network":
                sectionColorResourceId = R.color.teacher_network;
                break;
            case "Film":
                sectionColorResourceId = R.color.film;
                break;
            case "Books":
                sectionColorResourceId = R.color.books;
                break;
            case "Education":
                sectionColorResourceId = R.color.education;
                break;
            case "Football":
                sectionColorResourceId = R.color.football;
                break;
            case "US news":
                sectionColorResourceId = R.color.us_news;
                break;
            case "Culture":
                sectionColorResourceId = R.color.culture;
                break;
            default:
                sectionColorResourceId = R.color.def;
                break;
        }
        return ContextCompat.getColor(getContext(), sectionColorResourceId);
    }

    /**
     * Check if there is an author's name or not
     */
    private String getAuthorName(String author) {
        if (author == "null") {
            author = "Author N/A";
        } else {
            author = author;
        }
        return author;
    }
}
